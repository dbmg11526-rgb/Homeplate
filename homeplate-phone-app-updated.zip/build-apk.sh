#!/bin/bash
# Build an Android APK from the hosted app with Google's Bubblewrap (run on Linux Lite).
#   ./build-apk.sh YOURNAME.github.io        (the host where you published this folder, no https://)
set -e
HOST="$1"; [ -n "$HOST" ] || { echo "usage: $0 host   e.g. $0 daniel.github.io"; exit 1; }
command -v java >/dev/null && command -v node >/dev/null || {
  echo "Install prerequisites first:  sudo apt install -y openjdk-17-jdk nodejs npm"; exit 1; }
mkdir -p ~/.npm-global && npm config set prefix ~/.npm-global
export PATH="$HOME/.npm-global/bin:$PATH"
command -v bubblewrap >/dev/null || npm install -g @bubblewrap/cli

WORK=~/homeplate-apk; mkdir -p "$WORK"; cd "$WORK"
echo ">> Answer the prompts: accept the defaults, say YES if asked to download the Android SDK,"
echo ">> and choose a password you will remember for the signing key."
bubblewrap init --manifest="https://$HOST/manifest.webmanifest"
bubblewrap build

# Digital Asset Links: proves the app owns the site so it opens full-screen with no address bar.
PKG=$(node -p "require('./twa-manifest.json').packageId")
ALIAS=$(node -p "require('./twa-manifest.json').signingKey.alias")
KS=$(node -p "require('./twa-manifest.json').signingKey.path")
FP=$(keytool -list -v -keystore "$KS" -alias "$ALIAS" 2>/dev/null | awk -F'SHA256: ' '/SHA256:/{print $2; exit}')
mkdir -p .well-known
cat > .well-known/assetlinks.json <<JSON
[{"relation":["delegate_permission/common.handle_all_urls"],
  "target":{"namespace":"android_app","package_name":"$PKG","sha256_cert_fingerprints":["$FP"]}}]
JSON
echo
echo "DONE."
echo "1) Copy  $WORK/.well-known/assetlinks.json  into your published site at  /.well-known/assetlinks.json"
echo "2) Send  $WORK/app-release-signed.apk  to your Moto (USB, Drive, or: adb install app-release-signed.apk)"
echo "3) On the phone allow 'install unknown apps' for the app you open the APK from."
echo "Keep android.keystore and its password safe – you need them for every future update."
